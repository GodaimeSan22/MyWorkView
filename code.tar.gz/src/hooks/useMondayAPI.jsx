// src/hooks/useMondayAPI.jsx
import { useCallback } from 'react';
import mondaySdk from 'monday-sdk-js';

const monday = mondaySdk();

export const useMondayAPI = () => {
  // query - це GraphQL запит
  // variables - змінні для запиту
  // retries - кількість повторних спроб у випадку Rate Limit
  // delay - початкова затримка перед повторною спробою (в мс)
  const queryMonday = useCallback(async (query, variables = {}, retries = 3, delay = 500) => {
    try {
      const response = await monday.api(query, { variables });

      // Monday API часто повертає помилки у полі 'errors' навіть при статусі 200 OK
      if (response.errors) {
        const rateLimitError = response.errors.some(err => err.message.includes('Rate limit passed') || err.message.includes('Rate limit exceeded'));

        if (rateLimitError && retries > 0) {
          console.warn(`useMondayAPI: Rate limit hit, retrying in ${delay / 1000}s... (Retries left: ${retries - 1})`);
          await new Promise(resolve => setTimeout(resolve, delay));
          // Рекурсивний виклик з меншою кількістю спроб і подвійною затримкою
          return queryMonday(query, variables, retries - 1, delay * 2);
        }
        // Якщо це не помилка Rate Limit або спроби вичерпано, кидаємо помилку далі
        throw new Error(response.errors.map(e => e.message).join('; '));
      }

      // Якщо помилок немає, повертаємо дані
      return response.data;
    } catch (error) {
      console.error("useMondayAPI: Помилка запиту до Monday API:", error);

      // Якщо помилка в catch блоці також стосується Rate Limit і є спроби
      if (error.message.includes('Rate limit passed') && retries > 0) {
        console.warn(`useMondayAPI: Rate limit hit (caught), retrying in ${delay / 1000}s... (Retries left: ${retries - 1})`);
        await new Promise(resolve => setTimeout(resolve, delay));
        return queryMonday(query, variables, retries - 1, delay * 2);
      }
      throw error; // Перекидаємо помилку далі, якщо це не ліміт або спроби вичерпано
    }
  }, []); // Пусті залежності, якщо monday об'єкт стабільний

  return { queryMonday };
};